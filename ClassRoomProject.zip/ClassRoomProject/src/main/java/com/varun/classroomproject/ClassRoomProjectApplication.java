package com.varun.classroomproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClassRoomProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(ClassRoomProjectApplication.class, args);
    }

}
