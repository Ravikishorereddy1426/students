package com.varun.classroomproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClassRoomProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
